#Version information. Keep up-to-date with version in setup.py

__version__ = "0.2.1"

#list of all modules
__modulelist__ = [
            "correlations",
            "gofr",
            "hb_analyze", 
            "lifetime",
            "msd",
            "veccor"
            ]
